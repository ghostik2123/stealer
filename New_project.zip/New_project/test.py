import sqlite3

# Подключение к старой базе данных
old_conn = sqlite3.connect('users.db')
old_cursor = old_conn.cursor()

# Подключение к новой базе данных
new_conn = sqlite3.connect('users_New.db')
new_cursor = new_conn.cursor()

# Выбор данных из старой базы данных
old_cursor.execute("SELECT * FROM users")
users = old_cursor.fetchall()

# Вставка данных в новую базу данных
for user in users:
    new_cursor.execute("INSERT INTO users (chat_id, user_name, registration_time, status) VALUES (?, ?, ?, ?)", user)

new_conn.commit()

# Закрытие соединений
old_conn.close()
new_conn.close()

# Удаление старой базы данных (если необходимо)
import os
os.remove('users.db')



    elif call.data == "profile":
        conn = sqlite3.connect('users.db', check_same_thread=False)
        cursor = conn.cursor()
        user_id = call.from_user.id
        cursor.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
        user_data = cursor.fetchone()
        if user_data:
            profile_text = f"User ID: {user_data[0]}\nUsername: {user_data[1]}\nFirst Name: {user_data[2]}\nLast Name: {user_data[3]}"
            bot.send_message(call.message.chat.id, profile_text)
        else:
            bot.send_message(call.message.chat.id, "User profile not found.")
        cursor.close()
        conn.close()










@bot.callback_query_handler(func=lambda call: True)
def callback_inline(call):
     try:
         if call.message:
             if call.data == "users":
                 conn = sqlite3.connect('users.db', check_same_thread=False)
                 cursor = conn.cursor()
                 cursor.execute("SELECT username FROM users")
                 users = cursor.fetchall()
                 users_list = '\n'.join([user[0] for user in users]) 
                 bot.send_message(call.message.chat.id, "All users:\n" + users_list)
                 cursor.close()
                 conn.close()
             elif call.data == "admin_func":
                 bot.send_message(call.message.chat.id, "All admin functions")
             elif call.data == "profile":
                 bot.send_message(call.message.chat.id, )

     except Exception as e:
         print(repr(e))
bot.polling()