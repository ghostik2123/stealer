import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import os
import sqlite3
from datetime import datetime

user_bug_report_state = {}

conn = sqlite3.connect('users.db', check_same_thread=False)
cursor = conn.cursor()

cursor.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER UNIQUE, user_name TEXT, registration_time TEXT, status TEXT)")
conn.commit()

bot = telebot.TeleBot("6121531136:AAEfcRMCzwRwHHwWx68c7E3SWDJ5XilTVjQ")

ADMIN_ID = 2023014289



def display_users_for_banning(call):
    conn = sqlite3.connect('users.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute("SELECT id, user_name, chat_id, status FROM users WHERE chat_id != ?", (call.from_user.id,))
    users = cursor.fetchall()
    keyboard = InlineKeyboardMarkup()
    for user in users:
        user_id = user[0]
        user_name = user[1] if user[1] else "NoName"
        user_chat_id = user[2]
        user_status = user[3]
        button_text = f"{user_id} - @{user_name} - {user_status}"
        callback_data = f"ban_user_{user_chat_id}"
        button = InlineKeyboardButton(button_text, callback_data=callback_data)
        keyboard.add(button)
    bot.send_message(call.message.chat.id, "Выберите пользователя для бана:", reply_markup=keyboard)
    cursor.close()
    conn.close()

@bot.callback_query_handler(func=lambda call: call.data.startswith('ban_user_'))
def ban_user(call):
    user_id_to_ban = call.data.split('_')[-1]
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET status = 'Banned' WHERE chat_id = ?", (user_id_to_ban,))
    conn.commit()
    bot.answer_callback_query(call.id, "Пользователь был забанен.")
    bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text="Пользователь был забанен.", reply_markup=None)
    cursor.close()
    conn.close()

@bot.callback_query_handler(func=lambda call: call.data == "admin_func")
def admin_functions(call):
    display_users_for_banning(call)

@bot.message_handler(commands=["start"])
def start(message):
    user_id = message.from_user.id
    user_name = message.from_user.username  
    registration_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    status = "Admin" if user_id == ADMIN_ID else "User"

    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    cursor.execute("SELECT status FROM users WHERE chat_id = ?", (user_id,))
    user_status = cursor.fetchone()

    if user_status and user_status[0] == "Banned":
        bot.send_message(message.chat.id, "Вы заблокированы.")
    else:
        cursor.execute("SELECT * FROM users WHERE chat_id = ?", (user_id,))
        user = cursor.fetchone()

        if user is None:
            cursor.execute("INSERT INTO users (chat_id, user_name, registration_time, status) VALUES (?, ?, ?, ?)",
                           (user_id, user_name, registration_time, status))
            conn.commit()
            bot.send_message(message.chat.id, "Вы успешно зарегистрированы!")
        else:
            cursor.execute("UPDATE users SET user_name = ?, status = ? WHERE chat_id = ?",
                           (user_name, status, user_id))
            conn.commit()
            bot.send_message(message.chat.id, "Добро пожаловать обратно!")

    conn.close()
@bot.message_handler(commands=["bug"])
def bug_report_init(message):
    user_id = message.from_user.id
    user_bug_report_state[user_id] = True
    bot.send_message(message.chat.id, "Пожалуйста, опишите ошибку, с которой вы столкнулись.:")

@bot.message_handler(func=lambda message: user_bug_report_state.get(message.from_user.id, False))
def bug_report_receive(message):
    user_id = message.from_user.id
    user_bug_report_state[user_id] = False
    bot.forward_message(ADMIN_ID, message.chat.id, message.message_id)
    bot.send_message(message.chat.id, "Ваше сообщение об ошибке отправлено администратору. Спасибо!")


@bot.message_handler(commands=["menu"])
def menu(message):
    menu_markup = InlineKeyboardMarkup(row_width=2)
    if message.from_user.id == ADMIN_ID: 
        button1 = InlineKeyboardButton("Users", callback_data='users')
        button2 = InlineKeyboardButton("ADMIN Func", callback_data="admin_func")
        button_profile = InlineKeyboardButton("My Profile", callback_data='profile')

        menu_markup.add(button1, button2, button_profile)
        bot.send_message(message.chat.id, "ADMIN MENU", reply_markup=menu_markup)
    else:
        button_profile = InlineKeyboardButton("My Profile", callback_data='profile')
        menu_markup = InlineKeyboardMarkup(row_width=1).add(button_profile)
        bot.send_message(message.chat.id, "USER MENU", reply_markup=menu_markup)

@bot.callback_query_handler(func=lambda call: True)
def callback_inline(call):
    try:
        if call.message:
            if call.data == "users":
                conn = sqlite3.connect('users.db', check_same_thread=False)
                cursor = conn.cursor()
                cursor.execute("SELECT  id, user_name, chat_id, status FROM users")
                users = cursor.fetchall()
                keyboard = InlineKeyboardMarkup()
                for user in users:
                    id = user[0]
                    user_name = user[1]
                    user_chat_id = user[2]
                    user_status = user[3]
                    button_text = f" {id} - {user_name} ({user_chat_id}) - {user_status}"
                    callback_data = f"user_info_{user_chat_id}"
                    button = InlineKeyboardButton(button_text, callback_data=callback_data)
                    keyboard.add(button)
                bot.send_message(call.message.chat.id, "Все пользователи:", reply_markup=keyboard)
                cursor.close()
                conn.close()
            elif call.data == "admin_func":
                admin_keyboard = InlineKeyboardMarkup(row_width=1)
                buttonBan = InlineKeyboardButton("Ban", callback_data='ban_func')
                buttonstatus = InlineKeyboardButton("status", callback_data='status_func')
                admin_keyboard.add(buttonBan, buttonstatus)

                bot.send_message(call.message.chat.id, "Admin Fucn", reply_markup=admin_keyboard)

            if call.data == "ban_func":
                user_id_to_ban = call.data.split('_')[-1] 
                conn = sqlite3.connect('users.db')
                cursor = conn.cursor()
                cursor.execute("UPDATE users SET status = 'Banned' WHERE chat_id = ?", (user_id_to_ban,))
                conn.commit()
                cursor.close()
                conn.close()
                bot.answer_callback_query(call.id, "User has been banned.")
                bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text="Admin Func", reply_markup=None)
            elif call.data == "status_func":
                user_id, new_status = call.data.split('_')[2:]  # Assuming the callback data is 'change_status_{user_id}_{new_status}'
                valid_statuses = ['Admin', 'Moderator', 'User']
                if new_status in valid_statuses:
                    conn = sqlite3.connect('users.db')
                    cursor = conn.cursor()
                    cursor.execute("UPDATE users SET status = ? WHERE chat_id = ?", (new_status, user_id))
                    conn.commit()
                    bot.answer_callback_query(call.id, f"User status has been changed to {new_status}.")
                    cursor.close()
                    conn.close()
            else:
                 bot.answer_callback_query(call.id, "Invalid status.")
                
        elif call.data == "profile":
                conn = sqlite3.connect('users.db', check_same_thread=False)
                cursor = conn.cursor()
                user_id = call.from_user.id
                cursor.execute("SELECT * FROM users WHERE chat_id=?", (user_id,))
                user_data = cursor.fetchone()
                if user_data:
                    profile_text = f"*UID:* `{user_data[0]}`\n*Имя пользователя:* @{user_data[2]}\n*Время регистрации:* {user_data[3]}\n*Статус:* {user_data[4]}"
                    bot.send_message(call.message.chat.id, profile_text, parse_mode='Markdown')
                else:
                    bot.send_message(call.message.chat.id, "Профиль не найден.")
                cursor.close()
                conn.close()
    except Exception as e:
        print(repr(e))
bot.polling()